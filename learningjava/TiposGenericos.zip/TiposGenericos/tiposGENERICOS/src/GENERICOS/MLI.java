package GENERICOS;

import java.util.ArrayList;

public class MLI extends MLIMPL<Integer>{
    
}
