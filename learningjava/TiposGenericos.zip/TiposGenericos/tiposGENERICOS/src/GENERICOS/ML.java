package GENERICOS;

public interface ML<T> {
    public void add(T o);
    public void remove(T o); 
}